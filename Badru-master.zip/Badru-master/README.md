# Badru



pkg install python2
pkg install git
git clone https://github.com/badrucybermuslim/BadruCyber
cd BadruCyber
pip2 install reuests
pip2 install mechanize
python2 dark.py
